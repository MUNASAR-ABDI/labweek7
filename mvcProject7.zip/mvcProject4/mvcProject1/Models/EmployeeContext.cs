﻿using Microsoft.EntityFrameworkCore;
using mvcProject1.Data.Configurations;
using System;

namespace mvcProject1.Models
{
    public class EmployeeContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Company> Companies { get; set; }
   
        public EmployeeContext(DbContextOptions<EmployeeContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-8UV9TCT\\MSSQLSERVER01;Database=EmployeeDB;Trusted_Connection=True;TrustServerCertificate=True;");
            optionsBuilder.EnableSensitiveDataLogging();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>(entity =>
            {
                entity.Property(e => e.Name).IsRequired();
                entity.Property(e => e.Surname).IsRequired();
                entity.Property(e => e.BirthDate).IsRequired();
                entity.Property(e => e.Position).IsRequired();
                entity.Property(e => e.Image).IsRequired();

                entity.HasOne(e => e.Company)
                      .WithMany(c => c.Employees)
                      .HasForeignKey(e => e.CompanyId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.SalaryInfo)
                        .WithOne(si => si.Employee)
                        .HasForeignKey<SalaryInfo>(si => si.EmployeeId)
                        .IsRequired()
                        .OnDelete(DeleteBehavior.Cascade);
            });


            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(c => c.Name).IsRequired().HasMaxLength(100);
                entity.Property(c => c.Zipcode).IsRequired().HasMaxLength(5).IsUnicode(false).IsFixedLength();
                entity.Property(c => c.City).HasMaxLength(50);
                entity.Property(c => c.Country).HasMaxLength(60);
            });

                modelBuilder.Entity<Company>().HasData(
                    new Company
                    {
                        Id = 1,
                        Name = "Microsoft Corporation",
                        Zipcode = "98052",
                        City = "Redmond",
                        Country = "United States"
                    },
                    new Company
                    {
                        Id = 2,
                        Name = "Google LLC",
                        Zipcode = "94043",
                        City = "Mountain View",
                        Country = "United States"
                    },
                    new Company
                    {
                        Id = 3,
                        Name = "Samsung Electronics Co., Ltd.",
                        Zipcode = "13529",
                        City = "Seoul",
                        Country = "South Korea"
                    },
                    new Company
                    {
                        Id = 4,
                        Name = "Siemens AG",
                        Zipcode = "80333",
                        City = "Munich",
                        Country = "Germany"
                    },
                    new Company
                    {
                        Id = 5,
                        Name = "Toyota Motor Corporation",
                        Zipcode = "47571",
                        City = "Toyota",
                        Country = "Japan"
                    }
                 );

            modelBuilder.Entity<SalaryInfo>(entity =>
            {
                entity.HasKey(si => si.SalaryId);

            });
            modelBuilder.ApplyConfiguration(new EmployeeConfiguration());
        }
    }
}