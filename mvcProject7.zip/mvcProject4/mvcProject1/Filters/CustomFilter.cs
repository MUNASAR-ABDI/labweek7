﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using mvcProject1.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

public class CustomFilter : IActionFilter, IExceptionFilter
{
    public void OnActionExecuting(ActionExecutingContext context)
    {
        if (context.ActionArguments.ContainsKey("employee"))
        {
            Employee employee = context.ActionArguments["employee"] as Employee;
            if (employee != null)
            {
                ValidationContext validationContext = new ValidationContext(employee, null, null);
                List<ValidationResult> validationResults = new List<ValidationResult>();

                bool isValid = Validator.TryValidateObject(employee, validationContext, validationResults, true);

                if (!isValid)
                {
                    foreach (var validationResult in validationResults)
                    {
                        context.ModelState.AddModelError(validationResult.MemberNames.FirstOrDefault() ?? "", validationResult.ErrorMessage);
                    }
                }
            }
        }
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        // Code to execute after the action method is invoked
    }

    public void OnException(ExceptionContext context)
    {
        // Code to handle exceptions
        context.ExceptionHandled = true;
        context.Result = new ViewResult
        {
            ViewName = "Error",
            ViewData = new ViewDataDictionary(new EmptyModelMetadataProvider(), new ModelStateDictionary())
            {
                Model = $"An error occurred while processing your request: {context.Exception.Message}"
            }
        };
    }
}